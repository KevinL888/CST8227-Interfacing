package com.example.game;

import android.content.Intent;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private static final String ABOUT_DIALOG_TAG = "About Dialog";
    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    private Toast toast;
    private EditText userNumber;
    private Button guessButton;
    private Button resetButton;
    private int userGuessNumber;
    private int theNumber;
    private int highGuessCount;
    private int lowGuessCount;
    private int perfectWin;
    private int winCount;
    private boolean win;
    private int loseCount;
    private int guessCounter = 0;
    private Random random;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        userNumber = findViewById(R.id.userNumber);
        guessButton = findViewById(R.id.guess);
        resetButton = findViewById(R.id.reset);
        random = new Random();
        theNumber = random.nextInt(1000) +1;


        guessButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Parse the number that was given by the user in the EditText Field
                try {
                    userGuessNumber = Integer.parseInt(userNumber.getText().toString());
                }
                catch(NumberFormatException e) {
                    userNumber.setError("Must input a numeric value from 0-1000");
                    userNumber.requestFocus();
                }
                if(userGuessNumber < 1 || userGuessNumber>1000) {
                    userNumber.setError("Must input a numeric value from 0-1000");
                    userNumber.requestFocus();
                }
                else {
                    if(guessCounter <10 && !win) {
                        guessCounter++;
                        if (guessCounter <= 5 && userGuessNumber == theNumber) {
                            perfectWin++;
                            winCount++;
                            win = true;
                            userNumber.setEnabled(false);
                            toast = Toast.makeText(getApplicationContext(), "Superior Win!", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.TOP|Gravity.CENTER,0,250);
                            toast.show();
                        } else if (userGuessNumber == theNumber) {
                            winCount++;
                            win = true;
                            userNumber.setEnabled(false);
                            toast = Toast.makeText(getApplicationContext(), "Excellent Win!", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.TOP|Gravity.CENTER,0,250);
                            toast.show();
                        } else if(userGuessNumber > theNumber){
                            highGuessCount++;
                            toast = Toast.makeText(getApplicationContext(), "Guess is too high!", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.TOP|Gravity.CENTER,0,250);
                            toast.show();
                        }
                        else {
                            lowGuessCount++;
                            toast = Toast.makeText(getApplicationContext(), "Guess is too low!", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.TOP|Gravity.CENTER,0,250);
                            toast.show();
                        }

                        if(guessCounter == 10 && !win) {
                            userNumber.setEnabled(false);
                            loseCount++;
                            toast = Toast.makeText(getApplicationContext(), "Please Reset Game!", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.TOP|Gravity.CENTER,0,250);
                            toast.show();
                        }
                    }
                    else {
                        if(win) {
                            toast = Toast.makeText(getApplicationContext(), "You've already won the game please reset!", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.TOP|Gravity.CENTER,0,250);
                            toast.show();
                        }
                        else {
                            toast = Toast.makeText(getApplicationContext(), "Please Reset Game!", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, 250);
                            toast.show();
                        }
                    }
                }

            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userNumber.setEnabled(true);
                guessCounter = 0;
                highGuessCount = 0;
                lowGuessCount = 0;
                win = false;
                userNumber.setText("");
                theNumber = random.nextInt(1000)+1;
                toast = Toast.makeText(getApplicationContext(), "Game is reset.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.TOP|Gravity.CENTER,0,250);
                toast.show();
            }
        });


        resetButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent intent = new Intent( getApplicationContext(), ResultActivity.class );

                intent.setFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP );

                intent.putExtra( "theNumber", theNumber );
                intent.putExtra( "userGuessNumber", userGuessNumber );
                intent.putExtra( "guessCounter", guessCounter );
                intent.putExtra( "highGuessCount", highGuessCount );
                intent.putExtra( "lowGuessCount", lowGuessCount );
                intent.putExtra( "perfectWin", perfectWin );
                intent.putExtra( "winCount", winCount );
                intent.putExtra( "loseCount", loseCount );

                startActivity( intent );

                Log.i(LOG_TAG, "LEAVE onClick()");

                return true;
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here.
        int id = item.getItemId();

        if (id == R.id.action_about) {
            DialogFragment newFragment = new AboutDialogFragment();
            newFragment.show(getSupportFragmentManager(), ABOUT_DIALOG_TAG);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}

package com.example.game;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    private TextView theNumber;
    private TextView userGuessNumber;
    private TextView guessCounter;
    private TextView highGuessCount;
    private TextView lowGuessCount;
    private TextView perfectWin;
    private TextView winCount;
    private TextView loseCount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        theNumber = findViewById(R.id.theNumberDisplay);
        userGuessNumber = findViewById(R.id.userNumberDisplay);
        guessCounter = findViewById(R.id.guessCounterDisplay);
        highGuessCount = findViewById(R.id.highGuessCountDisplay);
        lowGuessCount = findViewById(R.id.lowGuessCountDisplay);
        perfectWin = findViewById(R.id.perfectWinDisplay);
        winCount = findViewById(R.id.winCountDisplay);
        loseCount = findViewById(R.id.loseCountDisplay);


        Bundle bundle = getIntent().getExtras();

        if(bundle != null) {
            theNumber.setText("The Number: "+ bundle.getInt("theNumber"));
            userGuessNumber.setText("Your Number: "+bundle.getInt("userGuessNumber"));
            guessCounter.setText("# of Guesses: "+ bundle.getInt("guessCounter"));
            highGuessCount.setText("High Guesses: "+ bundle.getInt("highGuessCount"));
            lowGuessCount.setText("Low Guesses: "+bundle.getInt("lowGuessCount"));
            perfectWin.setText("Perfect Wins: "+bundle.getInt("perfectWin"));
            winCount.setText("Number of Wins: "+bundle.getInt("winCount"));
            loseCount.setText("Number of Losses: "+bundle.getInt("loseCount"));
        }
    }
}

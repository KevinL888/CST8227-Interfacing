package com.example.loginexample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;



public class LoginActivity extends AppCompatActivity {
    private static final String LOG_TAG = LoginActivity.class.getSimpleName();
    private EditText User_Text;
    private EditText Pass_Text;
    private CheckBox Check_Box;
    private Button loginButton;
    private LoginButtonHandler lbh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        User_Text = findViewById(R.id.username);
        Pass_Text = findViewById(R.id.password);
        Check_Box = findViewById(R.id.checkBox);
        loginButton = findViewById(R.id.loginButton);
        lbh = new LoginButtonHandler();
        loginButton.setOnClickListener(lbh);
    }
  class LoginButtonHandler implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            String username = User_Text.getText().toString();
            String password = Pass_Text.getText().toString();
            boolean rememberMe = Check_Box.isChecked();

            String regex="^[a-z]{2}[a-z0-9]{2}[0-9]{4}$";

            if(!username.matches(regex)) {
                User_Text.setError("the username is mandatory\n" +
                        "the length of the username must be exactly 8 characters in length\n" +
                        "each of the first 2 positions can only be lower-case alphabetic characters (a-z)\n" +
                        "positions 3 and 4 can either be a lower-case alphabetical character (a-z) OR a digit (0-9)\n" +
                        "positions 5 thru 8 (inclusive) must be digits (0-9)");
                User_Text.requestFocus();
            }
            else if(password.length()<5 ) {
                Pass_Text.setError("the password is mandatory\n" +
                        "the length of the password is greater than or equal to 5 ( >= 5 )");
                Pass_Text.requestFocus();
            }
            else{
                Toast toast = Toast.makeText(getApplicationContext(), R.string.toastMessage, Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.TOP|Gravity.CENTER,0,255);
                toast.show();

                Toast.makeText(getApplicationContext(), "Email: " + username + " pw: " + password + " remember? " + rememberMe, Toast.LENGTH_LONG).show();

                Intent intent = new Intent( getApplicationContext(), HomeActivity.class );
                intent.setFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP );
                intent.putExtra( "username", username );
                intent.putExtra( "userPassword", password );
                intent.putExtra( "rememberMe", rememberMe );
                startActivity( intent );

                Log.i(LOG_TAG, "LEAVE onClick()");


                User_Text.setText("");
                Pass_Text.setText("");
                Check_Box.setChecked(false);
            }
        }
  }
}

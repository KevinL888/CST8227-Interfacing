package com.example.loginexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {

    private TextView homeUserName;
    private TextView homeUserPassword;
    private CheckBox homeCheckBox;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        homeUserName = findViewById(R.id.usernameHome);
        homeUserPassword = findViewById(R.id.passwordHome);
        homeCheckBox = findViewById(R.id.checkBox2);

        Bundle bundle = getIntent().getExtras();
        if(bundle != null) {
            String usernameFromLoginActivity = bundle.getString("username");
            String userPasswordFromLoginActivity = bundle.getString("userPassword");
            boolean userCheckBoxFromLoginActivity = bundle.getBoolean("rememberMe");
            homeUserName.setText(usernameFromLoginActivity);
            homeUserPassword.setText(userPasswordFromLoginActivity);
            homeCheckBox.setChecked(userCheckBoxFromLoginActivity);
        }
    }
}
